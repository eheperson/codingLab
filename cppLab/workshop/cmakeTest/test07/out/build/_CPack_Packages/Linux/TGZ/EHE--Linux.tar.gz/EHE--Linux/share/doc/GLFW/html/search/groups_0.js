var searchData=
[
  ['context_20reference_788',['Context reference',['../group__context.html',1,'']]]
];
