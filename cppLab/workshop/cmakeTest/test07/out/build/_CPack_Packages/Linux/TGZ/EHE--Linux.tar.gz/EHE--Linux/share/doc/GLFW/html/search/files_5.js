var searchData=
[
  ['news_2edox_564',['news.dox',['../news_8dox.html',1,'']]]
];
