var searchData=
[
  ['getting_20started_809',['Getting started',['../quick_guide.html',1,'']]]
];
