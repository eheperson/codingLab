var searchData=
[
  ['window_20reference_803',['Window reference',['../group__window.html',1,'']]]
];
